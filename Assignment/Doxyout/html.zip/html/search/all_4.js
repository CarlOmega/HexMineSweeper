var searchData=
[
  ['onobjectleftclick',['onObjectLeftClick',['../class_minesweeper_1_1_board.html#a7e283de1291a4ed985a6099dcbbd4962',1,'Minesweeper::Board']]],
  ['onobjectrightclick',['onObjectRightClick',['../class_minesweeper_1_1_board.html#abce9d7c9117d2e09520dcb5f39642182',1,'Minesweeper::Board']]]
];
